#include "myheader.h"

char *ft_strstr(char *str, char *toFind)
{
    unsigned int counter;
    unsigned int counter2;

    counter = 0;
    while (str[counter])
    {
        counter2 = 0;
        while (str[counter + counter2] == toFind[counter2])
        {
            if (toFind[counter2 + 1] == 0)
                return (str + counter);
            counter2++;
        }
        counter++;
    }
    return (0);
}

char *mylang(char *str)
{
    unsigned int counter;
    char *beginPoint;
    char *endPoint;
    
    char *deneme = "int";
    char *keyWord = "omer";

    beginPoint = ft_strstr(str, keyWord);
    if (beginPoint != 0)
    {
        endPoint = beginPoint + strlen(keyWord);

        memcpy(beginPoint, deneme, strlen(deneme));
        memset(beginPoint + strlen(deneme), 32, strlen(keyWord) - strlen(deneme));
/*
        while (beginPoint < endPoint)
        {

            beginPoint++;
        }
*/
    }
    return (str);
    counter = 0;
    while (str[counter])
    {

        counter++;
    } 
}