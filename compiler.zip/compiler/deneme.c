#include <stdio.h>

int main()
{
    omer a = 42;

    printf("%d\n", a);

    return (0);
}