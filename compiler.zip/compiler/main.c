#include "myheader.h"

char *myjoin(char *s1, char *s2)
{
    unsigned int counter;
    unsigned int counter2;
    char *ret_val;

    if (s1 == 0)
    {
        s1 = malloc(1);
        s1[0] = 0;
    }

    ret_val = malloc(strlen(s1) + 2);

    counter = 0;
    while (s1[counter])
    {
        ret_val[counter] = s1[counter];
        counter++;
    }
    ret_val[counter] = s2[0];
    counter++;
    ret_val[counter] = 0;
    return (ret_val);
}


char *readFile(char *dir)
{
    int fd;
    char buff;
    char *ret_val;
    int readed;

    fd = open(dir, O_RDONLY);

    ret_val = 0;
    readed = -2;
    while (readed >= 0 || readed == -2)
    {
        readed = read(fd, &buff, 1);
        if (readed <= 0)
        {
            return (ret_val);
        }
        ret_val = myjoin(ret_val, &buff);
    }

    return (ret_val);
}

char *writeFile(char *str)
{
    int fd;

    str = mylang(str);

    if(!fork())
    {
        system("touch .tmp.c");
        exit(0);
    }
    wait(NULL);

    fd = open(".tmp.c", O_RDWR);

    write(fd, str, strlen(str));
}

void    runCmd(char *cmd)
{
    if (!fork())
    {
        system(cmd);
    }
    wait(NULL);
}

int main(int argc, char **argv)
{

    char *tmp;
    tmp = readFile(argv[1]);

    writeFile(tmp);

    runCmd("gcc ./.tmp.c");

    runCmd("rm -rf .tmp.c");


    wait(NULL);
    //system("gcc main.c");

    //printf("%s\n", tmp);
    free(tmp);
    return (0);
}